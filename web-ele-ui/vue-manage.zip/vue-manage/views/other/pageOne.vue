<template>
    <div>我是page1页面</div>
</template>
<script>
export default {
    name: 'PageOne',
    data () {
        return {}
    }
}
</script>
