<template>
    <div>我是pageTow页面</div>
</template>
<script>
export default {
    name: 'PageTow',
    data () {
        return {}
    }
}
</script>
