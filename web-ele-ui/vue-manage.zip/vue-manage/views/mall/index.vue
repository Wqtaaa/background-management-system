<template>
    <div>我是商品管理页面</div>
</template>
<script>
export default {
    name: 'Mall',
    data () {
        return {}
    }
}
</script>
