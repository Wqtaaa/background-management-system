export default {
    baseUrl: {
        dev: '/api/',
        pro: ''
    }
}